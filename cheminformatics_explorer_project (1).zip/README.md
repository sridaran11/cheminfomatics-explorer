# Cheminformatics Explorer

A Streamlit app for educational molecular exploration: 2D depiction, generated 3D conformers, formula, molecular weight, SMILES, bond analysis, stereochemistry, and downloads.

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Run:

```bash
streamlit run app.py
```

## Notes

- Molecule-name lookup uses the public PubChem PUG REST API and requires internet access.
- SMILES input can be used without PubChem.
- 3D conformers are computational estimates, not experimental structures.
- Sigma/pi counts are estimates for teaching. Aromatic bonding is delocalized.
- Stereochemistry is reported when it is specified/assigned in the input.
- The 3D viewer loads 3Dmol.js from its public CDN, so the browser needs internet access.

## Deploy on Streamlit Community Cloud

Push `app.py` and `requirements.txt` to a GitHub repository, then create an app at https://share.streamlit.io/ and select the repository, branch, and `app.py`.
